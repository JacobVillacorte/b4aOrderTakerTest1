﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Private SQLProducts As SQL ' local to this activity for now
	Private xui As XUI


End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Private Panel1 As Panel
	Private lbllogout As Label
	Private lblperson As Label
	Private lblLoggedInUser As Label
	Private Spinner1 As Spinner
	Private ScrollView1 As ScrollView
	Private pnlBottomNav As Panel
	Private lblDash As Label
	Private lblDashIcon As Label
	Private lblHistory As Label
	Private lblHistoryIcon As Label
	Private lblInventory As Label
	Private lblInventoryIcon As Label
	Private lblOrders As Label
	Private lblOrdersIcon As Label
	Private pnlDash As Panel
	Private pnlHistory As Panel
	Private pnlInventory As Panel
	Private pnlOrders As Panel
	Private bttnAddOrder As Button
	Private pnlAddOrderHomeTotal As Panel
	Private lblExitAddOrderHome As Label
	Private pnlDim As Panel
	Private btnAddItems As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	Activity.LoadLayout("userOrders")
	' Display current logged in user
	lblLoggedInUser.Text = "Welcome, " & Main.LoggedInUser
	
	If FirstTime Then
		If File.Exists(File.DirInternal, "productsTest1.db") = False Then
			File.Copy(File.DirAssets, "productsTest1.db", File.DirInternal, "productTest1.db")
		End If
	End If

	SQLProducts.Initialize(File.DirInternal, "productTest1.db", True)

	' Now you can call ShowAddItemCard
	'ShowAddItemCard

	' ===== SCROLLVIEW INTERNAL PANEL =====
	ScrollView1.Panel.Width = ScrollView1.Width
	ScrollView1.Panel.Height = ScrollView1.Height   ' initial height; grow if you add cards

	' Optional: set hint text for spinner
	Dim vendorList As List
	vendorList.Initialize
	vendorList.Add("Choose Vendor") ' this will be your hint
	Spinner1.AddAll(vendorList)
	Spinner1.SelectedIndex = 0
	Spinner1.TextColor = Colors.Gray
	
'	' ===== Display product cards from DB =====
'	Dim cursor As Cursor
'	cursor = SQLProducts.ExecQuery("SELECT * FROM products")
'	Dim topPos As Int = 10dip
'
'	For i = 0 To cursor.RowCount - 1
'		cursor.Position = i
'		Dim sku As String = cursor.GetString("sku")
'		Dim name As String = cursor.GetString("name")
'		Dim price As Double = cursor.GetDouble("price")
'		Dim packNumber As Int = cursor.GetInt("pack_number")
'
'		Dim card As Panel
'		card = CreateProductCard(sku, name, price, packNumber, topPos)
'		ScrollView1.Panel.AddView(card, card.Left, card.Top, card.Width, card.Height)
'
'		topPos = topPos + card.Height + 10dip
'	Next
'	cursor.Close
'
'	ScrollView1.Panel.Height = topPos + 10dip
	
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Private Sub pnlInventory_Click
	StartActivity(userInventory)
End Sub

Private Sub pnlHistory_Click
	StartActivity(userHistory)
End Sub

Private Sub pnlDash_Click
	StartActivity(userDashboard)
End Sub

Private Sub lbllogout_Click
    
	Main.LoggedInUser = ""   ' Clear session
	StartActivity(Main)
	Controls.SetAnimation("slide_right_in", "slide_right_out")
	
	Activity.Finish
    
End Sub

'Sub CreateProductCard(sku As String, name As String, price As Double, packNumber As Int, topPos As Int) As Panel
'	Dim pnl As Panel
'	pnl.Initialize("")
'	pnl.Color = Colors.White
'	pnl.Left = 10dip
'	pnl.Width = ScrollView1.Width - 20dip
'	pnl.Top = topPos
'	pnl.Height = 120dip ' adjusted for 4 labels
'
'	' SKU Label
'	Dim lblSKU As Label
'	lblSKU.Initialize("")
'	lblSKU.Text = "SKU: " & sku
'	lblSKU.Left = 10dip
'	lblSKU.Top = 10dip
'	lblSKU.Width = pnl.Width - 20dip
'	lblSKU.Height = 20dip
'	pnl.AddView(lblSKU, lblSKU.Left, lblSKU.Top, lblSKU.Width, lblSKU.Height)
'
'	' Name Label
'	Dim lblName As Label
'	lblName.Initialize("")
'	lblName.Text = name
'	lblName.Left = 10dip
'	lblName.Top = lblSKU.Top + lblSKU.Height + 4dip
'	lblName.Width = pnl.Width - 20dip
'	lblName.Height = 20dip
'	pnl.AddView(lblName, lblName.Left, lblName.Top, lblName.Width, lblName.Height)
'
'	' Price Label
'	Dim lblPrice As Label
'	lblPrice.Initialize("")
'	lblPrice.Text = "₱" & price
'	lblPrice.Left = 10dip
'	lblPrice.Top = lblName.Top + lblName.Height + 4dip
'	lblPrice.Width = pnl.Width - 20dip
'	lblPrice.Height = 20dip
'	pnl.AddView(lblPrice, lblPrice.Left, lblPrice.Top, lblPrice.Width, lblPrice.Height)
'
'	' Pack Number Label
'	Dim lblPack As Label
'	lblPack.Initialize("")
'	lblPack.Text = "Pack Number: " & packNumber
'	lblPack.Left = 10dip
'	lblPack.Top = lblPrice.Top + lblPrice.Height + 4dip
'	lblPack.Width = pnl.Width - 20dip
'	lblPack.Height = 20dip
'	pnl.AddView(lblPack, lblPack.Left, lblPack.Top, lblPack.Width, lblPack.Height)
'
'	Return pnl
'End Sub

Private Sub bttnAddOrder_Click
	pnlDim.Visible = True
	pnlDim.BringToFront
	pnlAddOrderHomeTotal.Visible = True
	pnlAddOrderHomeTotal.BringToFront
	
	bttnAddOrder.Visible = False 
	lblExitAddOrderHome.Visible = True
    btnAddItems.Visible = True
	
End Sub

Private Sub lblExitAddOrderHome_Click
	pnlAddOrderHomeTotal.Visible = False
	pnlDim.Visible = False
	bttnAddOrder.Visible = True
End Sub



Private Sub btnAddItems_Click
	
End Sub

Private Sub pnlDim_Click
    
End Sub